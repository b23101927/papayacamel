import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.io.PrintStream;

public class TCPServerMain{
	
	public static void main(String[] args) {
		ServerClass server = new ServerClass();
		server.start();
	}
}
class ServerClass implements Broadcast {
	ArrayList<ClientData> clientDatas = new ArrayList<>();
	public ServerClass() {
		
	}
	public void start () {
		try {
			ServerSocket serverSock = new ServerSocket(8080);
			System.out.print("Server started...");
			while (true) {
				Socket cSock = serverSock.accept();
				new Thread(new ServerThread(cSock,clientDatas, this)).start();
				System.out.println("connecting");
			}
		} catch (IOException e) {
			System.out.println("disconnected...");
		}
	}
	
	@Override
	public void sendAllMsg(String msg) {
		for(int i =0;i < clientDatas.size();i++) {
			try {
				PrintStream writer = new PrintStream(clientDatas.get(i).getSocket().getOutputStream(), true);
//				System.out.println(clientDatas.get(i).getSocket()+" "+i);
				writer.println(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
//		System.out.println(msg);
		
	}
	private PrintStream PrintStream(OutputStream outputStream, boolean b) {
		// TODO Auto-generated method stub
		return null;
	}
	private Object PrintStream(Socket socket) {
		// TODO Auto-generated method stub
		return null;
	}
}