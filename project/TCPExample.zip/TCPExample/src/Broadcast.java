
public interface Broadcast {
	public void sendAllMsg(String msg);
}
